I. INSTALLING EXTENSIONS

Simply put the JAR file of the extension into this directory and restart install4j. The screens,
actions and form components that are contributed by the extension will be shown in the appropriate registries
in the install4j GUI.

Extensions will only be shipped with the generated installer if they are actually used by your project.

II. DEVELOPING EXTENSIONS

For more information on the development of extension for install4j, please see

Help topics->Extending install4j->Extensions

in the install4j documentation.