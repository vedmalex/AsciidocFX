
treeData = [
  {label: 'install4j help', id: 'install4j.welcome', href: 'welcome.html', imageUrl : 'images/help_overview_18.png'},
  {label: 'Licensing', id: 'install4j.licensing', href: 'licensing.html'},
  {label: 'Help topics', id: 'install4j.helptopics.$folder$', href: 'helptopics/$folder$.html', children: [
    {label: 'Concepts', id: 'install4j.helptopics.concepts.$folder$', href: 'helptopics/concepts/$folder$.html', children: [
      {label: 'Projects', id: 'install4j.helptopics.concepts.projects', href: 'helptopics/concepts/projects.html'},
      {label: 'File sets and components', id: 'install4j.helptopics.concepts.files', href: 'helptopics/concepts/files.html'},
      {label: 'Screens and actions', id: 'install4j.helptopics.concepts.screensAndActions', href: 'helptopics/concepts/screensAndActions.html'},
      {label: 'Form screens', id: 'install4j.helptopics.concepts.formScreens', href: 'helptopics/concepts/formScreens.html'},
      {label: 'Layout groups', id: 'install4j.helptopics.concepts.layoutGroups', href: 'helptopics/concepts/layoutGroups.html'},
      {label: 'Variables', id: 'install4j.helptopics.concepts.variables', href: 'helptopics/concepts/variables.html'},
      {label: 'VM parameters', id: 'install4j.helptopics.concepts.vmParameters', href: 'helptopics/concepts/vmParameters.html'},
      {label: 'JRE bundles', id: 'install4j.helptopics.concepts.jreBundles', href: 'helptopics/concepts/jreBundles.html'},
      {label: 'Services', id: 'install4j.helptopics.concepts.services', href: 'helptopics/concepts/services.html'},
      {label: 'Elevation of privileges', id: 'install4j.helptopics.concepts.privileges', href: 'helptopics/concepts/privileges.html'},
      {label: 'Merged projects', id: 'install4j.helptopics.concepts.mergedProjects', href: 'helptopics/concepts/mergedProjects.html'},
      {label: 'Auto-update functionality', id: 'install4j.helptopics.concepts.autoUpdate', href: 'helptopics/concepts/autoUpdate.html'},
      {label: 'Code signing', id: 'install4j.helptopics.concepts.codeSigning', href: 'helptopics/concepts/codeSigning.html'},
      {label: 'Styling of DMGs on Mac OS X', id: 'install4j.helptopics.concepts.dmgStyling', href: 'helptopics/concepts/dmgStyling.html'}
    ]},
    {label: 'Generated installers', id: 'install4j.helptopics.installers.$folder$', href: 'helptopics/installers/$folder$.html', children: [
      {label: 'Installer modes', id: 'install4j.helptopics.installers.installerModes', href: 'helptopics/installers/installerModes.html'},
      {label: 'Command line options', id: 'install4j.helptopics.installers.options', href: 'helptopics/installers/options.html'},
      {label: 'Response files', id: 'install4j.helptopics.installers.responseFile', href: 'helptopics/installers/responseFile.html'},
      {label: 'JRE search', id: 'install4j.helptopics.installers.jre', href: 'helptopics/installers/jre.html'},
      {label: 'Downloads', id: 'install4j.helptopics.installers.downloads', href: 'helptopics/installers/downloads.html'},
      {label: 'Updates', id: 'install4j.helptopics.installers.updates', href: 'helptopics/installers/updates.html'},
      {label: 'Error handling', id: 'install4j.helptopics.installers.errors', href: 'helptopics/installers/errors.html'}
    ]},
    {label: 'Extending install4j', id: 'install4j.helptopics.extending.$folder$', href: 'helptopics/extending/$folder$.html', children: [
      {label: 'Using the install4j API', id: 'install4j.helptopics.extending.api', href: 'helptopics/extending/api.html'},
      {label: 'Extensions', id: 'install4j.helptopics.extending.extensions', href: 'helptopics/extending/extensions.html'}
    ]}
  ]},
  {label: 'Reference', id: 'install4j.reference.$folder$', href: '$folder$.html', children: [
    {label: 'Configuration steps', id: 'install4j.steps', href: 'steps/overview.html', imageUrl : 'images/help_overview_18.png'},
    {label: 'Step 1: General Settings', id: 'install4j.steps.general.$folder$', href: 'steps/general/$folder$.html', children: [
      {label: 'Overview', id: 'install4j.steps.general', href: 'steps/general/general.html', imageUrl : 'images/help_overview_18.png'},
      {label: 'Application info', id: 'install4j.steps.general.appInfo', href: 'steps/general/appInfo.html'},
      {label: 'Java version', id: 'install4j.steps.general.javaVersion', href: 'steps/general/javaVersion.html'},
      {label: 'Languages', id: 'install4j.steps.general.languages', href: 'steps/general/languages.html'},
      {label: 'Media file options', id: 'install4j.steps.general.mediaOptions', href: 'steps/general/mediaOptions.html'},
      {label: 'Code signing', id: 'install4j.steps.general.codeSigning', href: 'steps/general/codeSigning.html'},
      {label: 'Merged projects', id: 'install4j.steps.general.mergedProjects', href: 'steps/general/mergedProjects.html'},
      {label: 'Compiler variables', id: 'install4j.steps.general.variables', href: 'steps/general/variables.html'},
      {label: 'Project options', id: 'install4j.steps.general.projectOptions', href: 'steps/general/projectOptions.html'},
      {label: 'Dialogs', id: 'install4j.steps.general.dialogs.$folder$', href: 'steps/general/dialogs/$folder$.html', children: [
        {label: 'Search sequence dialog', id: 'install4j.steps.general.dialogs.searchSequence', href: 'steps/general/dialogs/searchSequence.html'},
        {label: 'Language selection dialog', id: 'install4j.steps.general.dialogs.languageSelection', href: 'steps/general/dialogs/languageSelection.html'},
        {label: 'Variable selection dialogs', id: 'install4j.steps.general.dialogs.variableSelection', href: 'steps/general/dialogs/variableSelection.html'},
        {label: 'Variables edit dialogs', id: 'install4j.steps.general.dialogs.variableEdit', href: 'steps/general/dialogs/variableEdit.html'},
        {label: 'Input dialog', id: 'install4j.steps.general.dialogs.inputDialog', href: 'steps/general/dialogs/inputDialog.html'},
        {label: 'Configure JDKs dialog', id: 'install4j.steps.general.dialogs.configureJdks', href: 'steps/general/dialogs/configureJdks.html'},
        {label: 'Merged projects edit dialog', id: 'install4j.steps.general.dialogs.mergedProjects', href: 'steps/general/dialogs/mergedProjects.html'}
      ]}
    ]},
    {label: 'Step 2: Files', id: 'install4j.steps.files.$folder$', href: 'steps/files/$folder$.html', children: [
      {label: 'Overview', id: 'install4j.steps.files', href: 'steps/files/files.html', imageUrl : 'images/help_overview_18.png'},
      {label: 'Defining the distribution tree', id: 'install4j.steps.files.definition.$folder$', href: 'steps/files/definition/$folder$.html', children: [
        {label: 'Overview', id: 'install4j.steps.files.definition', href: 'steps/files/definition/definition.html'},
        {label: 'File wizard', id: 'install4j.steps.files.definition.wizard', href: 'steps/files/definition/wizard.html'},
        {label: 'Wizard steps', id: 'install4j.steps.files.definition.steps.$folder$', href: 'steps/files/definition/steps/$folder$.html', children: [
          {label: 'Select directory', id: 'install4j.steps.files.definition.steps.selectDirectory', href: 'steps/files/definition/steps/selectDirectory.html'},
          {label: 'Select files', id: 'install4j.steps.files.definition.steps.selectFiles', href: 'steps/files/definition/steps/selectFiles.html'},
          {label: 'Install options', id: 'install4j.steps.files.definition.steps.installOptions', href: 'steps/files/definition/steps/installOptions.html'},
          {label: 'Exclude files and directories', id: 'install4j.steps.files.definition.steps.exclude', href: 'steps/files/definition/steps/exclude.html'},
          {label: 'Exclude suffixes', id: 'install4j.steps.files.definition.steps.excludeSuffixes', href: 'steps/files/definition/steps/excludeSuffixes.html'}
        ]}
      ]},
      {label: 'Viewing the results', id: 'install4j.steps.files.results', href: 'steps/files/results.html'},
      {label: 'File options', id: 'install4j.steps.files.options', href: 'steps/files/options.html'},
      {label: 'Defining installation components', id: 'install4j.steps.files.components', href: 'steps/files/components.html'},
      {label: 'Dialogs', id: 'install4j.steps.files.dialogs.$folder$', href: 'steps/files/dialogs/$folder$.html', children: [
        {label: 'Distribution file chooser dialog', id: 'install4j.steps.files.dialogs.chooser', href: 'steps/files/dialogs/chooser.html'},
        {label: 'Folder properties dialog', id: 'install4j.steps.files.dialogs.folderProperties', href: 'steps/files/dialogs/folderProperties.html'}
      ]}
    ]},
    {label: 'Step 3: Launchers', id: 'install4j.steps.launcher.$folder$', href: 'steps/launcher/$folder$.html', children: [
      {label: 'Overview', id: 'install4j.steps.launcher', href: 'steps/launcher/launcher.html', imageUrl : 'images/help_overview_18.png'},
      {label: 'Launcher wizard', id: 'install4j.steps.launcher.wizard', href: 'steps/launcher/wizard.html', imageUrl : 'images/help_overview_18.png'},
      {label: 'Wizard steps', id: 'install4j.steps.launcher.wizard.$folder$', href: 'steps/launcher/wizard/$folder$.html', children: [
        {label: 'Executable', id: 'install4j.steps.launcher.wizard.executable', href: 'steps/launcher/wizard/executable.html'},
        {label: 'Icon', id: 'install4j.steps.launcher.wizard.icon', href: 'steps/launcher/wizard/icon.html'},
        {label: 'Java invocation', id: 'install4j.steps.launcher.wizard.java', href: 'steps/launcher/wizard/java.html'},
        {label: 'VM options file', id: 'install4j.steps.launcher.wizard.vmOptionsFile', href: 'steps/launcher/wizard/vmOptionsFile.html'},
        {label: 'Splash screen', id: 'install4j.steps.launcher.wizard.splash', href: 'steps/launcher/wizard/splash.html'},
        {label: 'Advanced options', id: 'install4j.steps.launcher.wizard.advanced.$folder$', href: 'steps/launcher/wizard/$advancedFolder$.html', children: [
          {label: 'Redirection', id: 'install4j.steps.launcher.wizard.redirection', href: 'steps/launcher/wizard/redirection.html'},
          {label: 'Windows version info', id: 'install4j.steps.launcher.wizard.windowsVersion', href: 'steps/launcher/wizard/windowsVersion.html'},
          {label: 'Windows manifest options', id: 'install4j.steps.launcher.wizard.executionLevel', href: 'steps/launcher/wizard/executionLevel.html'},
          {label: 'UNIX options', id: 'install4j.steps.launcher.wizard.unixOptions', href: 'steps/launcher/wizard/unixOptions.html'},
          {label: 'Mac OS X options', id: 'install4j.steps.launcher.wizard.macosOptions', href: 'steps/launcher/wizard/macosOptions.html'},
          {label: 'Menu integration', id: 'install4j.steps.launcher.wizard.menu', href: 'steps/launcher/wizard/menu.html'},
          {label: 'Native libraries', id: 'install4j.steps.launcher.wizard.native', href: 'steps/launcher/wizard/native.html'},
          {label: 'Preferred VM', id: 'install4j.steps.launcher.wizard.vmType', href: 'steps/launcher/wizard/vmType.html'},
          {label: 'Text lines on splash screen', id: 'install4j.steps.launcher.wizard.splashScreenOptions', href: 'steps/launcher/wizard/splashScreenOptions.html'}
        ]},
        {label: 'Dialogs', id: 'install4j.steps.launcher.wizard.dialogs.$folder$', href: 'steps/launcher/wizard/dialogs/$folder$.html', children: [
          {label: 'Main class selection dialog', id: 'install4j.steps.launcher.wizard.dialogs.mainClass', href: 'steps/launcher/wizard/dialogs/mainClass.html'},
          {label: 'Class path dialog', id: 'install4j.steps.launcher.wizard.dialogs.classpath', href: 'steps/launcher/wizard/dialogs/classpath.html'},
          {label: 'Native libraries entry dialog', id: 'install4j.steps.launcher.wizard.dialogs.nativeLibs', href: 'steps/launcher/wizard/dialogs/nativeLibs.html'},
          {label: 'Visual positioning', id: 'install4j.steps.launcher.wizard.dialogs.visual', href: 'steps/launcher/wizard/dialogs/visual.html'}
        ]}
      ]}
    ]},
    {label: 'Step 4: Installer', id: 'install4j.steps.installer.$folder$', href: 'steps/installerGui/$folder$.html', children: [
      {label: 'Overview', id: 'install4j.steps.installer', href: 'steps/installerGui/installerGui.html', imageUrl : 'images/help_overview_18.png'},
      {label: 'Screens &amp; actions', id: 'install4j.steps.installer.screensAndActions', href: 'steps/installerGui/screensAndActions.html'},
      {label: 'Configuring applications', id: 'install4j.steps.installer.applications', href: 'steps/installerGui/applications.html'},
      {label: 'Configuring screens', id: 'install4j.steps.installer.screens', href: 'steps/installerGui/screens.html'},
      {label: 'Available screens', id: 'install4j.steps.installer.availableScreens', href: 'steps/installerGui/availableScreens.html'},
      {label: 'Configuring actions', id: 'install4j.steps.installer.actions', href: 'steps/installerGui/actions.html'},
      {label: 'Available actions', id: 'install4j.steps.installer.availableActions', href: 'steps/installerGui/availableActions.html'},
      {label: 'Screen and action groups', id: 'install4j.steps.installer.groups', href: 'steps/installerGui/groups.html'},
      {label: 'Configuring form components', id: 'install4j.steps.installer.formComponents', href: 'steps/installerGui/formComponents.html'},
      {label: 'Layout groups', id: 'install4j.steps.installer.layoutGroups', href: 'steps/installerGui/layoutGroups.html'},
      {label: 'Available form components', id: 'install4j.steps.installer.availableFormComponents', href: 'steps/installerGui/availableFormComponents.html'},
      {label: 'Custom code', id: 'install4j.steps.installer.customCode', href: 'steps/installerGui/customCode.html'},
      {label: 'Update options', id: 'install4j.steps.installer.updateOptions', href: 'steps/installerGui/updateOptions.html'},
      {label: 'Auto-update options', id: 'install4j.steps.installer.autoUpdateOptions', href: 'steps/installerGui/autoUpdateOptions.html'},
      {label: 'Dialogs', id: 'install4j.steps.installer.dialogs.$folder$', href: 'steps/installerGui/dialogs/$folder$.html', children: [
        {label: 'Custom code entry', id: 'install4j.steps.installer.dialogs.customCodeEntry', href: 'steps/installerGui/dialogs/customCodeEntry.html'},
        {label: 'Class selector dialog', id: 'install4j.steps.installer.dialogs.classSelector', href: 'steps/installerGui/dialogs/classSelector.html'},
        {label: 'Registry dialog', id: 'install4j.steps.installer.dialogs.registry', href: 'steps/installerGui/dialogs/registry.html'},
        {label: 'Application template dialog', id: 'install4j.steps.installer.dialogs.applicationTemplates', href: 'steps/installerGui/dialogs/applicationTemplates.html'},
        {label: 'Link selection dialog', id: 'install4j.steps.installer.dialogs.link', href: 'steps/installerGui/dialogs/link.html'},
        {label: 'String edit dialog', id: 'install4j.steps.installer.dialogs.strings', href: 'steps/installerGui/dialogs/strings.html'},
        {label: 'Java code editor', id: 'install4j.steps.installer.dialogs.javaCode', href: 'steps/installerGui/dialogs/javaCode.html'},
        {label: 'Java editor settings', id: 'install4j.steps.installer.dialogs.javaEditorSettings', href: 'steps/installerGui/dialogs/javaEditorSettings.html'},
        {label: 'Code gallery', id: 'install4j.steps.installer.dialogs.codeGallery', href: 'steps/installerGui/dialogs/codeGallery.html'},
        {label: 'Key map editor', id: 'install4j.steps.installer.dialogs.keyMap', href: 'steps/installerGui/dialogs/keyMap.html'},
        {label: 'ID selection dialog', id: 'install4j.steps.installer.dialogs.idSelection', href: 'steps/installerGui/dialogs/idSelection.html'},
        {label: 'Integration wizard', id: 'install4j.steps.installer.dialogs.integrationWizard', href: 'steps/installerGui/dialogs/integrationWizard.html'}
      ]}
    ]},
    {label: 'Step 5: Media', id: 'install4j.steps.media.$folder$', href: 'steps/media/$folder$.html', children: [
      {label: 'Overview', id: 'install4j.steps.media', href: 'steps/media/media.html', imageUrl : 'images/help_overview_18.png'},
      {label: 'Media file types', id: 'install4j.steps.media.mediaFileTypes', href: 'steps/media/mediaFileTypes.html'},
      {label: 'Media file wizard', id: 'install4j.steps.media.wizard', href: 'steps/media/wizard.html'},
      {label: 'Wizard steps', id: 'install4j.steps.media.steps.$folder$', href: 'steps/media/steps/$folder$.html', children: [
        {label: 'Platform', id: 'install4j.steps.media.steps.platform', href: 'steps/media/steps/platform.html'},
        {label: 'Installer options', id: 'install4j.steps.media.steps.installerOptions', href: 'steps/media/steps/installerOptions.html'},
        {label: 'Data files', id: 'install4j.steps.media.steps.dataFiles', href: 'steps/media/steps/dataFiles.html'},
        {label: 'Bundled JREs', id: 'install4j.steps.media.steps.bundledJre', href: 'steps/media/steps/bundledJre.html'},
        {label: 'Customize project defaults', id: 'install4j.steps.media.steps.customize', href: 'steps/media/steps/customize.html'},
        {label: '32-bit or 64-bit (Windows)', id: 'install4j.steps.media.steps.32or64bit', href: 'steps/media/steps/32or64Bit.html'},
        {label: 'Executable processing (Windows)', id: 'install4j.steps.media.steps.executableProcessing', href: 'steps/media/steps/executableProcessing.html'},
        {label: 'Launcher (Mac OS X single bundle)', id: 'install4j.steps.media.steps.macLauncher', href: 'steps/media/steps/macLauncher.html'},
        {label: '64-bit settings (Mac OS X)', id: 'install4j.steps.media.steps.mac64Bit', href: 'steps/media/steps/mac64Bit.html'},
        {label: 'Additional files in DMG (Mac OS X)', id: 'install4j.steps.media.steps.topLevelFiles', href: 'steps/media/steps/topLevelFiles.html'},
        {label: 'DMG options (Mac OS X)', id: 'install4j.steps.media.steps.dmgOptions', href: 'steps/media/steps/dmgOptions.html'}
      ]}
    ]},
    {label: 'Step 6: Build', id: 'install4j.steps.build.$folder$', href: 'steps/build/$folder$.html', children: [
      {label: 'Overview', id: 'install4j.steps.build', href: 'steps/build/build.html', imageUrl : 'images/help_overview_18.png'},
      {label: 'Build options', id: 'install4j.steps.build.options', href: 'steps/build/options.html'}
    ]},
    {label: 'JRE download wizard', id: 'install4j.jreDownload', href: 'jreDownload.html'},
    {label: 'JRE bundle wizard', id: 'install4j.jreBundle', href: 'jreBundle.html'},
    {label: 'Preferences', id: 'install4j.preferences', href: 'preferences.html'},
    {label: 'Command line compiler', id: 'install4j.cli.$folder$', href: 'cli/$folder$.html', children: [
      {label: 'Overview', id: 'install4j.cli', href: 'cli/cli.html', imageUrl : 'images/help_overview_18.png'},
      {label: 'Options', id: 'install4j.cli.options', href: 'cli/options.html'},
      {label: 'Using install4j with ant', id: 'install4j.cli.ant', href: 'cli/ant.html'},
      {label: 'Using install4j with gradle', id: 'install4j.cli.gradle', href: 'cli/gradle.html'},
      {label: 'Using install4j with maven', id: 'install4j.cli.maven', href: 'cli/maven.html'},
      {label: 'Relative resource paths', id: 'install4j.cli.relative', href: 'cli/relative.html'}
    ]},
    {label: 'Launcher API', id: 'install4j.api.launcher.$folder$', href: 'api/$launcherFolder$.html', children: [
      {label: 'Controlling the splash screen', id: 'install4j.api.splash', href: 'api/splash.html'},
      {label: 'Receiving startup notifications', id: 'install4j.api.singleInstance', href: 'api/singleInstance.html'}
    ]}
  ]}
];
